git pull
git status
git add .
git commit . -m "update"
#git status
git push